﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Answer2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char[] incrct = { 'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'C', 'A', 'D', 'A', 'B', 'C' };
            string wrong = "\n";
            char[] crct = new char[20];
            StreamReader a;
            a = File.OpenText("correct.txt");

            int i = 0;
            int right = 0;
            while (i < incrct.Length && !a.EndOfStream)
            {
                if (incrct[i].ToString() == a.ReadLine())
                {
                    right++;
                }

                else
                {
                    wrong += "Questions" + (i + 1) + "\n";
                }
                i++;
            }
            a.Close();
            if (right > 15)
            {
                MessageBox.Show("You are Pass.");
            }
            else
            {
                MessageBox.Show("You are Fail.");
            }
            a.Close();

            label1.Text = "Correctly answered :" + right + "\n" +
            "Incorrectly answered :" + (20 - right) + "\n" +
            "List of incorrectly answered questions :" + wrong;
        }
    }
}
    
