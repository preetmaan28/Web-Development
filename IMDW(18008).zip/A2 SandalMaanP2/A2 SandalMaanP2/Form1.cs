﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2_SandalMaanP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //for sphere
            textBox1.Enabled = true;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //for cylinder
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // for rectangular prism
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //volume of sphere
            if (radioButton1.Checked)
            {
                string r = textBox1.Text;
                double R;
                double.TryParse(r, out R);
                double cal1;
                cal1 = (4.0/ 3 )* 3.14159*R*R*R;
                textBox5.Text = cal1.ToString();
            }
            // volume of cylinder
            else if (radioButton2.Checked)
            {
                string r = textBox1.Text;
                double R;
                double.TryParse(r, out R);
                string h = textBox2.Text;
                double H;
               double.TryParse(h, out H);
                
                double cal2;
                cal2 = 3.14159 *R*R*H;
                textBox5.Text = cal2.ToString();
            }
            //volume of rectangular prism
            else
            {
                string l = textBox3.Text;
                string w = textBox4.Text;
                double L = double.Parse(l);
                double W = double.Parse(w);
                string h = textBox2.Text;
                double H = double.Parse(h);
                double cal3 = L * W * H;
                textBox5.Text = cal3.ToString();
            }
        }
    }
}
