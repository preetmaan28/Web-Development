﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2SandalMaanP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string age = textBox1.Text;
            double a;
            double.TryParse(age, out a);
            try
            {
                if (radioButton1.Checked)
                {
                    if (a <= 18)
                    {
                        textBox2.Text = "$300";
                        textBox3.Text = "$100";
                    }
                    if (a >= 19 && a <= 49)
                    {
                        textBox2.Text = "$500";
                        textBox3.Text = "$100";
                    }
                    if (a >= 50)
                    {
                        textBox2.Text = "$400";
                        textBox3.Text = "$100";
                    }
                }
                else
                {
                    if (a <= 18)
                    {
                        textBox2.Text = "$300";
                        textBox3.Text = " No extra fee";
                    }
                    if (a >= 19 && a <= 49)
                    {
                        textBox2.Text = "$500";
                        textBox3.Text = "No extra fee";
                    }
                    if (a >= 50)
                    {
                        textBox2.Text = "$400";
                        textBox3.Text = "No extra fee";
                    }
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("fill all the details accurately.");
            }
            string n= textBox7.Text;
           // int num;
           //nt.TryParse(n,out num);
            switch (n)
            {
                case "fall":
                    textBox4.Text = "$250";
                    if (radioButton1.Checked)
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$734.5";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$960.5";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$847.5";
                        }
                    }
                    else
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = " $621.5";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$847.5";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$734.5";
                        }
                    }
                        break;
                case "Winter":
                    textBox4.Text = "$220";
                    if (radioButton1.Checked)
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$700.6";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$926.6";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$813.6";
                        }
                    }
                    else
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = " $587.6";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$813.6";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$700.6";
                        }
                    }
                    break;
                case "summer":
                    textBox4.Text = "$150";
                    if (radioButton1.Checked)
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$619.5";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$847.5";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$734.5";
                        }
                    }
                    else
                    {
                        if (a <= 18)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$508.5";
                        }
                        if (a >= 19 && a <= 49)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$734.5";
                        }
                        if (a >= 50)
                        {
                            textBox5.Text = "26%";
                            textBox6.Text = "$621.5";
                        }
                    }
                    break;
                default:
                    textBox4.Text = "Enter-fall,winter or summer only.";
                    break;

            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
